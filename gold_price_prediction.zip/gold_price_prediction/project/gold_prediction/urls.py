# gold_prediction/urls.py
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views  # built-in auth views
from predictor import views

urlpatterns = [
    path('admin/', admin.site.urls),
    # Home page is the prediction page
    path('', include('predictor.urls')),
    # Login/Logout
    path('login/', auth_views.LoginView.as_view(template_name='predictor/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/login/'), name='logout'),
]
