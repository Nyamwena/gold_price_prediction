# predictor/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Home page (prediction view)
    path('', views.predict_gold_price, name='home'),
    # Dashboard overview page
    path('dashboard/', views.dashboard, name='dashboard'),
    # Historical performance view with date range selection
    path('historical_performance/', views.historical_performance, name='historical_performance'),
    # Backtesting tool view
    path('backtesting/', views.backtesting, name='backtesting'),
    # Model information page
    path('information/', views.information, name='information'),
    # Usage analytics page
    # path('analytics/', views.analytics, name='analytics'),
    path('plots/', views.plots, name='plots'),
]
