# predictor/views.py
import datetime
import os
import joblib
import numpy as np
import pandas as pd
import yfinance as yf
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
import plotly.graph_objs as go
from plotly.offline import plot
from prophet import Prophet
from .models import ChartEvent
from django import forms
import csv
from django.http import HttpResponse



# Set base directory and file paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCALER_PATH = os.path.join(BASE_DIR, 'scaler.joblib')
MODELS_PATH = os.path.join(BASE_DIR, 'all_models.joblib')
DATA_PATH = os.path.join(BASE_DIR, 'gold_price_dataset_extended.csv')

# Load scaler and models once at startup
scaler = joblib.load(SCALER_PATH)
models = joblib.load(MODELS_PATH)

@login_required
def dashboard(request):
    # For demonstration, assume current gold price is the last entry of historical data.
    df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
    current_price = df['gold_price'].iloc[-1]
    first_price = df['gold_price'].iloc[0]
    pct_change = ((current_price / first_price) - 1) * 100

    # Additional metrics can be calculated as needed.
    context = {
        'current_price': current_price,
        'pct_change': pct_change,
        'forecast_plot': generate_forecast_plot(),
        'heatmap_div': generate_correlation_heatmap(),
        'closing_price_plot': generate_closing_price_plot_with_events(),
    }
    return render(request, 'predictor/dashboard.html', context)


class DateRangeForm(forms.Form):
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))


@login_required
def historical_performance(request):
    results_div = ""
    message = ""
    form = DateRangeForm(request.GET or None)
    if form.is_valid():
        start_date = form.cleaned_data['start_date']
        end_date = form.cleaned_data['end_date']
        # Read CSV data
        df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
        # Filter by the provided date range
        df_period = df.loc[str(start_date):str(end_date)]

        if df_period.empty:
            message = "No data available for the selected date range."
        else:
            # Calculate cumulative returns over the selected period.
            df_period['Cumulative Return'] = (df_period['gold_price'] / df_period['gold_price'].iloc[0] - 1) * 100

            # Create a Plotly chart for historical performance.
            trace = go.Scatter(x=df_period.index, y=df_period['gold_price'], mode='lines', name='Gold Price')
            trace_return = go.Scatter(x=df_period.index, y=df_period['Cumulative Return'], mode='lines',
                                      name='Cumulative Return')
            layout = go.Layout(title='Historical Performance', xaxis=dict(title='Date'))
            fig = go.Figure(data=[trace, trace_return], layout=layout)
            results_div = plot(fig, output_type='div', include_plotlyjs=False)
    context = {
        'form': form,
        'results_div': results_div,
        'message': message,
    }
    return render(request, 'predictor/historical_performance.html', context)


def fetch_latest_features():
    """
    Fetch the latest available values from Yahoo Finance for:
      - USD Index ("DX-Y.NYB")
      - S&P 500 ("^GSPC")
      - Crude Oil ("CL=F")
      - Silver ("SI=F")
      - VIX ("^VIX")
      - US 10Y Treasury Yield ("^TNX")
    Returns a list of values in the order used during training.
    """
    tickers = {
        'usd_index': "DX-Y.NYB",
        'sp500': "^GSPC",
        'crude_oil': "CL=F",
        'silver_price': "SI=F",
        'vix': "^VIX",
        '10Y_treasury_yield': "^TNX"
    }
    features = {}
    for key, ticker in tickers.items():
        data = yf.download(ticker, period="5d")
        if data.empty:
            raise ValueError(f"No data fetched for {ticker}")
        col = "Adj Close" if "Adj Close" in data.columns else "Close"
        features[key] = data[col].iloc[-1]
    return [
        features['usd_index'],
        features['sp500'],
        features['crude_oil'],
        features['silver_price'],
        features['vix'],
        features['10Y_treasury_yield']
    ]


def generate_closing_price_plot():
    """Generate an interactive Plotly plot of the gold closing prices."""
    df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
    trace = go.Scatter(x=df.index, y=df['gold_price'], mode='lines', name='Gold Price')
    layout = go.Layout(title='Gold Closing Prices', xaxis=dict(title='Date'), yaxis=dict(title='Price'))
    fig = go.Figure(data=[trace], layout=layout)
    return plot(fig, output_type='div', include_plotlyjs=False)


def generate_cumulative_returns_plot():
    """Generate a Plotly plot of cumulative returns for gold price."""
    df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
    df['Cumulative Return'] = (df['gold_price'] / df['gold_price'].iloc[0] - 1) * 100
    trace = go.Scatter(x=df.index, y=df['Cumulative Return'], mode='lines', name='Cumulative Return (%)')
    layout = go.Layout(title='Gold Cumulative Returns', xaxis=dict(title='Date'), yaxis=dict(title='Return (%)'))
    fig = go.Figure(data=[trace], layout=layout)
    return plot(fig, output_type='div', include_plotlyjs=False)


def generate_prediction_bar_chart(predictions):
    """Generate a bar chart showing the current predictions from each model."""
    names = list(predictions.keys())
    values = [predictions[name] for name in names]
    trace = go.Bar(x=names, y=values, name='Predicted Gold Price')
    layout = go.Layout(title='Current Predictions by Model', xaxis=dict(title='Model'), yaxis=dict(title='Gold Price'))
    fig = go.Figure(data=[trace], layout=layout)
    return plot(fig, output_type='div', include_plotlyjs=False)


@login_required
def predict_gold_price(request):
    """Home page: fetch live data, predict with each model, and display plots."""
    predictions = {}
    error_message = None
    try:
        features = fetch_latest_features()
        features_array = np.array(features).reshape(1, -1)
        features_scaled = scaler.transform(features_array)
        for name, model in models.items():
            pred = model.predict(features_scaled)[0]
            predictions[name] = pred
        # Generate interactive plots
        closing_price_plot = generate_closing_price_plot()
        cumulative_returns_plot = generate_cumulative_returns_plot()
        prediction_bar_chart = generate_prediction_bar_chart(predictions)
    except Exception as e:
        error_message = str(e)
        closing_price_plot = cumulative_returns_plot = prediction_bar_chart = ""

    context = {
        'predictions': predictions,
        'error_message': error_message,
        'closing_price_plot': closing_price_plot,
        'cumulative_returns_plot': cumulative_returns_plot,
        'prediction_bar_chart': prediction_bar_chart,
    }
    return render(request, 'predictor/predict.html', context)


@login_required
def information(request):
    """Information page: show details about models and performance metrics.
       For demonstration, we use a static dictionary of model metrics.
    """
    # In practice, you might load these from a file or database.
    model_info = {
        "LinearRegression": {"R2": 0.65, "MSE": 30.25},
        "RandomForest": {"R2": 0.80, "MSE": 20.10},
        "GradientBoosting": {"R2": 0.78, "MSE": 21.50},
        "SVR": {"R2": 0.60, "MSE": 35.00},
    }
    return render(request, 'predictor/information.html', {'model_info': model_info})


@login_required
def plots(request):
    """Plots page: show the interactive plots in a full-page view."""
    closing_price_plot = generate_closing_price_plot()
    cumulative_returns_plot = generate_cumulative_returns_plot()
    # You might also include the prediction bar chart or other plots.
    prediction_bar_chart = generate_prediction_bar_chart(
        {name: 0 for name in models.keys()})  # dummy bar chart placeholder
    context = {
        'closing_price_plot': closing_price_plot,
        'cumulative_returns_plot': cumulative_returns_plot,
        'prediction_bar_chart': prediction_bar_chart,
    }
    return render(request, 'predictor/plots.html', context)


def generate_forecast_plot():
    try:
        # Load historical data
        df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
        # Ensure numeric conversion
        df['gold_price'] = pd.to_numeric(df['gold_price'], errors='coerce')
        print("Historical Data Loaded:")
        print(df.head())

        # Reset index to convert the date index into a column.
        prophet_df = df.reset_index()

        # Determine the date column name. (Adjust if your CSV has a specific name.)
        if 'index' in prophet_df.columns:
            date_col = 'index'
        elif 'date' in prophet_df.columns:
            date_col = 'date'
        else:
            date_col = prophet_df.columns[0]

        # Rename columns to 'ds' (for dates) and 'y' (for gold_price)
        prophet_df = prophet_df.rename(columns={date_col: 'ds', 'gold_price': 'y'})
        prophet_df['ds'] = pd.to_datetime(prophet_df['ds'])
        print("Prophet DataFrame:")
        print(prophet_df.head())

        # Check last date and add a dummy row if needed
        last_hist_date = prophet_df['ds'].max().date()
        today = datetime.date.today()
        if last_hist_date < today:
            last_price = prophet_df['y'].iloc[-1]
            dummy = pd.DataFrame({'ds': [pd.Timestamp(today)], 'y': [last_price]})
            prophet_df = pd.concat([prophet_df, dummy], ignore_index=True)
            print("Dummy row added with price:", last_price)

        # Fit the Prophet model
        m = Prophet(daily_seasonality=True)
        m.fit(prophet_df)

        # Forecast the next 7 days
        future = m.make_future_dataframe(periods=7, freq='D')
        forecast = m.predict(future)
        print("Forecast Summary:")
        print(forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail())

        # Historical trace
        trace_actual = go.Scatter(
            x=prophet_df['ds'],
            y=prophet_df['y'],
            mode='lines',
            name='Historical',
            line=dict(color='blue', width=2)
        )

        # Filter forecast for dates after the last historical date
        forecast_mask = forecast['ds'] > prophet_df['ds'].max()
        forecast_df = forecast.loc[forecast_mask]

        # Forecast trace with thicker line and filled confidence interval
        trace_forecast = go.Scatter(
            x=forecast_df['ds'],
            y=forecast_df['yhat'],
            mode='lines',
            name='Forecast',
            line=dict(color='red', width=4)
        )
        # Confidence interval traces
        trace_upper = go.Scatter(
            x=forecast_df['ds'],
            y=forecast_df['yhat_upper'],
            mode='lines',
            name='Upper Confidence',
            line=dict(color='rgba(255, 0, 0, 0)'),
            showlegend=False
        )
        trace_lower = go.Scatter(
            x=forecast_df['ds'],
            y=forecast_df['yhat_lower'],
            mode='lines',
            name='Lower Confidence',
            line=dict(color='rgba(255, 0, 0, 0)'),
            fill='tonexty',
            fillcolor='rgba(255, 0, 0, 0.2)',
            showlegend=True
        )

        layout = go.Layout(
            title='Gold Price Forecast (Next 7 Days)',
            xaxis=dict(title='Date'),
            yaxis=dict(title='Price')
        )

        fig = go.Figure(data=[trace_actual, trace_forecast, trace_upper, trace_lower], layout=layout)

        # Return the Plotly div; print confirmation to debug
        div_output = plot(fig, output_type='div', include_plotlyjs=False)
        print("Plot generated successfully.")
        return div_output
    except Exception as e:
        print("Error generating forecast plot:", e)
        return "Error generating forecast plot: " + str(e)

def generate_correlation_heatmap():
    df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
    # Select the columns you want to include in the heatmap.
    cols = ['gold_price', 'usd_index', 'sp500', 'crude_oil', 'silver_price', 'vix', '10Y_treasury_yield']
    corr = df[cols].corr()

    heatmap = go.Heatmap(
        z=corr.values,
        x=corr.columns,
        y=corr.index,
        colorscale='Viridis'
    )
    layout = go.Layout(
        title='Correlation Heatmap of Market Indicators',
        xaxis=dict(title='Indicators'),
        yaxis=dict(title='Indicators')
    )
    fig = go.Figure(data=[heatmap], layout=layout)
    return plot(fig, output_type='div', include_plotlyjs=False)
def generate_closing_price_plot_with_events():
    df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
    trace = go.Scatter(x=df.index, y=df['gold_price'], mode='lines', name='Gold Price')
    annotations = []
    events = ChartEvent.objects.all()
    for event in events:
        annotations.append({
            'x': event.date.strftime('%Y-%m-%d'),
            'y': float(df.loc[str(event.date)]['gold_price']) if str(event.date) in df.index else None,
            'text': event.description,
            'showarrow': True,
            'arrowhead': 2
        })
    layout = go.Layout(
        title='Gold Closing Prices with Event Annotations',
        xaxis=dict(title='Date'),
        yaxis=dict(title='Price'),
        annotations=annotations
    )
    fig = go.Figure(data=[trace], layout=layout)
    return plot(fig, output_type='div', include_plotlyjs=False)


@login_required
def backtesting(request):
    results_div = ""
    message = ""
    form = DateRangeForm(request.GET or None)
    if form.is_valid():
        start_date = form.cleaned_data['start_date']
        end_date = form.cleaned_data['end_date']
        df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
        df_period = df.loc[str(start_date):str(end_date)]

        if df_period.empty:
            message = "No data available for the selected date range."
        else:
            features = ['usd_index', 'sp500', 'crude_oil', 'silver_price', 'vix', '10Y_treasury_yield']
            X_hist = df_period[features].values
            y_actual = df_period['gold_price'].values

            # Check again if X_hist has at least one row
            if X_hist.shape[0] == 0:
                message = "No feature data available for the selected date range."
            else:
                # Transform the features using the pre-saved scaler
                X_hist_scaled = scaler.transform(X_hist)
                predictions = {}
                for name, model in models.items():
                    predictions[name] = model.predict(X_hist_scaled)

                # For demonstration, plot actual vs. prediction for one model (e.g., RandomForest)
                trace_actual = go.Scatter(
                    x=df_period.index, y=y_actual, mode='lines', name='Actual'
                )
                trace_pred = go.Scatter(
                    x=df_period.index, y=predictions['RandomForest'], mode='lines', name='RandomForest Prediction'
                )
                layout = go.Layout(
                    title='Backtesting: Actual vs. RandomForest Prediction',
                    xaxis=dict(title='Date'),
                    yaxis=dict(title='Gold Price')
                )
                fig = go.Figure(data=[trace_actual, trace_pred], layout=layout)
                results_div = plot(fig, output_type='div', include_plotlyjs=False)

    context = {
        'form': form,
        'results_div': results_div,
        'message': message,
    }
    return render(request, 'predictor/backtesting.html', context)


@login_required
def download_report(request):
    # Generate a CSV report of predictions and/or historical performance.
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="gold_report.csv"'
    writer = csv.writer(response)
    writer.writerow(['Date', 'Gold Price', 'USD Index', 'S&P 500', 'Crude Oil', 'Silver Price', 'VIX', '10Y Treasury Yield'])
    df = pd.read_csv(DATA_PATH, parse_dates=True, index_col=0)
    for index, row in df.iterrows():
        writer.writerow([index, row['gold_price'], row['usd_index'], row['sp500'], row['crude_oil'], row['silver_price'], row['vix'], row['10Y_treasury_yield']])
    return response


@login_required
def plots(request):
    """View for the dedicated Plots page showing several interactive charts."""
    closing_price_plot = generate_closing_price_plot()
    cumulative_returns_plot = generate_cumulative_returns_plot()
    forecast_plot = generate_forecast_plot()
    heatmap_div = generate_correlation_heatmap()

    context = {
        'closing_price_plot': closing_price_plot,
        'cumulative_returns_plot': cumulative_returns_plot,
        'forecast_plot': forecast_plot,
        'heatmap_div': heatmap_div,
    }
    return render(request, 'predictor/plots.html', context)