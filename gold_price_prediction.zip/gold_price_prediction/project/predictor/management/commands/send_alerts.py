from django.core.management.base import BaseCommand
from django.core.mail import send_mail
import joblib
import numpy as np
import yfinance as yf
import os
import datetime


class Command(BaseCommand):
    help = 'Send alerts if gold prediction changes significantly'

    def handle(self, *args, **kwargs):
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        SCALER_PATH = os.path.join(BASE_DIR, 'scaler.joblib')
        MODELS_PATH = os.path.join(BASE_DIR, 'all_models.joblib')
        scaler = joblib.load(SCALER_PATH)
        models = joblib.load(MODELS_PATH)

        # Fetch features (for one model, for simplicity)
        def fetch_latest_features():
            tickers = {
                'usd_index': "DX-Y.NYB",
                'sp500': "^GSPC",
                'crude_oil': "CL=F",
                'silver_price': "SI=F",
                'vix': "^VIX",
                '10Y_treasury_yield': "^TNX"
            }
            features = {}
            for key, ticker in tickers.items():
                data = yf.download(ticker, period="5d")
                col = "Adj Close" if "Adj Close" in data.columns else "Close"
                features[key] = data[col].iloc[-1]
            return [
                features['usd_index'],
                features['sp500'],
                features['crude_oil'],
                features['silver_price'],
                features['vix'],
                features['10Y_treasury_yield']
            ]

        features = fetch_latest_features()
        features_array = np.array(features).reshape(1, -1)
        features_scaled = scaler.transform(features_array)
        current_pred = models['RandomForest'].predict(features_scaled)[0]

        # For demonstration, suppose we store the previous prediction in a file.
        prev_file = os.path.join(BASE_DIR, 'prev_pred.txt')
        previous_pred = None
        if os.path.exists(prev_file):
            with open(prev_file, 'r') as f:
                previous_pred = float(f.read().strip())
        # Save the current prediction
        with open(prev_file, 'w') as f:
            f.write(str(current_pred))

        threshold = 5.0  # set a threshold (in dollars) for example
        if previous_pred is not None and abs(current_pred - previous_pred) > threshold:
            # Send an email alert.
            send_mail(
                'Gold Price Prediction Alert',
                f'The predicted gold price changed from {previous_pred:.2f} to {current_pred:.2f}.',
                'from@example.com',
                ['to@example.com'],
                fail_silently=False,
            )
            self.stdout.write("Alert sent!")
        else:
            self.stdout.write("No significant change, no alert sent.")
