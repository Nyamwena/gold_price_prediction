import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt


# -------------------------------
# Helper Functions
# -------------------------------
def flatten_columns(df):
    """
    If the DataFrame has a MultiIndex in its columns,
    flatten it by taking the first level.
    """
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def get_price_data(ticker, start_date, end_date, primary_column="Adj Close", rename_to=None):
    """
    Downloads data for a given ticker between start_date and end_date,
    flattens the columns if necessary, and returns a DataFrame
    with a single column for the price data.

    If the primary_column is not available, falls back to 'Close'.
    If an error occurs or no data is returned, it returns None.
    """
    try:
        # Disable progress output to reduce clutter
        data = yf.download(ticker, start=start_date, end=end_date, progress=False)
    except Exception as e:
        print(f"Error downloading {ticker}: {e}")
        return None

    # Check if data is empty
    if data.empty:
        print(f"No data returned for {ticker}.")
        return None

    data = flatten_columns(data)

    # Determine which price column to use
    if primary_column in data.columns:
        col = primary_column
    elif "Close" in data.columns:
        col = "Close"
    else:
        print(
            f"Skipping {ticker}: Neither '{primary_column}' nor 'Close' found. Available columns: {data.columns.tolist()}")
        return None

    if rename_to is None:
        rename_to = ticker
    return data[[col]].rename(columns={col: rename_to})


# -------------------------------
# Define Date Range
# -------------------------------
start_date = "2022-01-01"
end_date = "2024-12-31"

# -------------------------------
# Download Data for Each Factor
# -------------------------------
tickers = {
    "gold_price": {"ticker": "GC=F", "primary_column": "Close"},
    "usd_index": {"ticker": "DX-Y.NYB", "primary_column": "Adj Close"},
    "sp500": {"ticker": "^GSPC", "primary_column": "Adj Close"},
    "crude_oil": {"ticker": "CL=F", "primary_column": "Adj Close"},
    "silver_price": {"ticker": "SI=F", "primary_column": "Adj Close"},
    "vix": {"ticker": "^VIX", "primary_column": "Adj Close"},
    "10Y_treasury_yield": {"ticker": "^TNX", "primary_column": "Adj Close"}
}

data_frames = {}
for name, info in tickers.items():
    print(f"Downloading data for {info['ticker']} as {name}...")
    df_temp = get_price_data(info['ticker'], start_date, end_date, primary_column=info['primary_column'],
                             rename_to=name)
    if df_temp is not None:
        data_frames[name] = df_temp
    else:
        print(f"Failed to download data for {info['ticker']}.")

# -------------------------------
# Merge All Datasets
# -------------------------------
if data_frames:
    # Merge on date index
    df_merged = pd.concat(data_frames.values(), axis=1)
    # Remove any rows with missing data to ensure consistency across factors.
    df_merged.dropna(inplace=True)

    # Save the Dataset to CSV
    csv_filename = "gold_price_dataset_extended.csv"
    df_merged.to_csv(csv_filename)
    print(f"Dataset generated and saved as '{csv_filename}'.")

    # -------------------------------
    # (Optional) Plot Selected Data for Visual Inspection
    # -------------------------------
    plt.figure(figsize=(14, 8))

    # Plot the first set of data if available
    if all(col in df_merged.columns for col in ['gold_price', 'usd_index', 'sp500']):
        plt.subplot(2, 1, 1)
        plt.plot(df_merged.index, df_merged['gold_price'], label='Gold Price (GC=F)', color='gold')
        plt.plot(df_merged.index, df_merged['usd_index'], label='USD Index (DX-Y.NYB)', color='green')
        plt.plot(df_merged.index, df_merged['sp500'], label='S&P 500 (^GSPC)', color='blue')
        plt.title("Gold Price and Key Market Indices (2022-2024)")
        plt.legend()

    # Plot the second set of data if available
    if all(col in df_merged.columns for col in ['crude_oil', 'silver_price', 'vix', '10Y_treasury_yield']):
        plt.subplot(2, 1, 2)
        plt.plot(df_merged.index, df_merged['crude_oil'], label='Crude Oil (CL=F)', color='black')
        plt.plot(df_merged.index, df_merged['silver_price'], label='Silver Price (SI=F)', color='silver')
        plt.plot(df_merged.index, df_merged['vix'], label='VIX (^VIX)', color='red')
        plt.plot(df_merged.index, df_merged['10Y_treasury_yield'], label='10Y Treasury Yield (^TNX)', color='purple')
        plt.title("Additional Factors Affecting Gold Price (2022-2024)")
        plt.legend()

    plt.tight_layout()
    plt.show()
else:
    print("No data was downloaded. Please check the ticker symbols or your internet connection.")
