newapi-key  '9a6a4e926eb843179a0e3f0c3851d055'

sentiments 

Map Changes to Sentiment:

Positive changes → Positive sentiment.
Negative changes → Negative sentiment.
Larger magnitude changes → Stronger sentiment values.

Synthetic Sentiment Generation:

Gold Change: Computes the percentage change in gold prices.
Synthetic Sentiment: Maps changes to a sentiment range [-1.0, 1.0] using a scaling factor (x * 10 in the example). Adjust this factor to control sensitivity.

Use Sentiment Analysis:
The script uses the VADER sentiment analyzer to calculate a sentiment score for each piece of text. The score ranges between:

-1.0: Extremely negative sentiment.
0.0: Neutral sentiment.
1.0: Extremely positive sentiment.


The gold price retrieved using the yfinance library (with the ticker symbol GC=F) refers to gold futures contracts traded on the commodities market. Specifically:

Gold Futures: These prices are typically quoted per troy ounce.
Currency: The price is usually in USD (United States Dollars).
What is a Troy Ounce?
A troy ounce is a unit of measure commonly used in the precious metals market.
1 troy ounce ≈ 31.1035 grams.
It differs from the standard ounce (avoirdupois ounce), which is approximately 28.35 grams.
Context of Gold Futures
Symbol GC=F: Represents gold futures traded on the COMEX (Commodity Exchange), part of the Chicago Mercantile Exchange (CME) group.
Contract Specifications: Each futures contract typically represents 100 troy ounces of gold.
Price Interpretation: When the Close price in the dataset shows, for example, $1,800, it means that one troy ounce of gold is priced at $1,800.
Relevance to Dataset
The dataset's gold price column (Gold Price) reflects the market price per troy ounce in USD, making it a standard metric for analysis and predictions. Let me know if you'd like to explore alternative gold price sources, such as spot prices or international currencies!





Current Model:
MSE of 0.0139: This is a relatively low error, indicating that, on average, the model's predictions are reasonably close to the actual values.
SMAPE of 16.98%: While there's room for improvement, a 17% error is not catastrophic, and many real-world models in financial or economic contexts can have higher errors. For instance, stock price prediction models often have higher errors due to market volatility.
Use of LSTM: LSTM is well-suited for time-series forecasting tasks like gold price prediction, as it captures temporal dependencies in data.


Future improvements:
Negative R² (-0.0117): This is a significant concern. Negative R² suggests that the model is not performing better than a simple mean model, which is problematic. The model is not explaining the variance in the data effectively.

Possible Reasons:
The model architecture may not be suitable for the complexity of the data.
The dataset may not have sufficient information or features to make accurate predictions.
There might be an issue with how the data is prepared (e.g., incorrect scaling, missing data, noise).
Training and Test Split: It's possible that the model is overfitting on the training set and underperforming on the test set. Consider performing cross-validation to get a better understanding of the model's generalization ability.

Model Performance vs. Industry Standards: In financial forecasting, a model with an R² close to zero or negative might not be useful, as it doesn't effectively capture market behavior. You would generally need an R² above 0.6 to 0.8 for a model to be considered good in practice, especially in a dynamic market like gold prices.


ALPHA_VANTAGE_API_KEY = 'PZP1REBAPKWLA24H'
FRED_API_KEY = '96f5d2b8ec085b3b8412af1b4ef2a8b0'




Visualization and Analysis:

Plotted the historical closing prices and the predicted vs. actual prices of Gold ETFs, facilitating a clear visual comparison and validation of the model’s performance.
Generated interactive plots using Plotly for enhanced data visualization and analysis.

Home Page: Provides an overview of closing price plots, prediction plots, cumulative returns, and current predictions.

Information Page: Details about the linear regression model, R-squared score, and other relevant information.

Plots Page: Displays closing price, prediction, and cumulative returns plots.

